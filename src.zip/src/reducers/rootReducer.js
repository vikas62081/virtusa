const initState={
    todos:[
        {id:1,content:"Wash your hand"},
        {id:2,content:"Cook to fish"}
      ]
}

const rootReduce=(state=initState,action)=>{
    console.log(action)
    if(typeof action===undefined)
        return state;
    switch(action.type)
    {
        case "DELETE_TODO":
             let newTodos=state.todos.filter(todo=>{
                return todo.id!==action.id;
            });
            return{...state,
                todos:newTodos
            }
        case "ADD_TODO":
            let newTodos_=[...state.todos,{id:Math.random(),content:action.content}]
            return{...state,
                todos:newTodos_
            }
    }
    return state;
}

export default rootReduce;