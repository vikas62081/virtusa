import React, { Component } from 'react'
import Todoes from './components/Todos'
import AddTodo from './components/AddTodo';

export default class App extends Component {
  render() {
    return (
      <div className="App container">
      <h1 className="text-center text-primary">Todo's</h1>
        <Todoes className="card-body" />
        <AddTodo />
      </div>
    )
  }
}
