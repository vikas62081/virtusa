import React from 'react';
import {connect} from 'react-redux';
import deleteTodo from './../actions/deleteTodo'

 function Todos(props) {
    const todoList = props.todos.length ? (props.todos.map(todo => {
        return (
            <div key={todo.id}>
                <li type="button" className="list-group-item list-group-item-action">
                 {todo.content} 
                 <i className="fa fa-trash float-right text-primary mx-2" title={"delete "+todo.content}
                  onClick={()=>{props.deleteTodo(todo.id)}}
                  aria-hidden="true"></i>
                 <i className="fa fa-edit float-right text-primary mx-2" title={"Edit "+todo.content}
                  onClick={()=>{props.handleUpdate(todo)}}></i>
                   </li>
                
            </div>
        )
    })) : (<div>
        <li className="list-group-item list-group-item-action"
                 title="Nothing to show">You don't have left todo's :)</li>
    </div>);
    return (
        <div>
            {todoList}
        </div>
    ) 
}


const mapStateToProps=(state)=>{
    return{
        todos:state.todos
    }
}


const mapDispatchToProps=(dispatch)=>{
    return{
        deleteTodo:(id)=>{
            dispatch(deleteTodo(id))
        }
    }
}
export default connect(mapStateToProps,mapDispatchToProps)(Todos)