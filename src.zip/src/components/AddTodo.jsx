import React, { Component } from 'react'
import { connect } from 'react-redux'
class AddTodo extends Component {
    state = {
        content: ''
    }
    handleChange = (e) => {
        this.setState({
            content: e.target.value
        })
    }
    handleSubmit = (e) => {
        e.preventDefault();
        this.props.AddTodo(this.state.content)
        this.setState({ content: '' })
    }
    render() {
        return (
            <div>
                <form onSubmit={this.handleSubmit}>
                    <div className="input-group input-group-lg fixed-bottom">
                        <input type="text" className="form-control" aria-label="Large"
                            placeholder="Write something to add"
                            onChange={this.handleChange} value={this.state.content}
                            aria-describedby="inputGroup-sizing-sm" />
                    </div>
                </form>
            </div>
        )
    }
}


const mapDispatchToProps = (dispatch) => {
    return {
        AddTodo: (content) => {
            dispatch({ type: "ADD_TODO", content: content })
        }
    }
}
export default connect(null, mapDispatchToProps)(AddTodo)
